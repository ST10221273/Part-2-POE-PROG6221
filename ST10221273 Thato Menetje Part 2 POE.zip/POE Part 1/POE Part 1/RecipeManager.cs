﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_Part_1
{
    // Class to manage recipes
    public class RecipeManager
    {
        private static List<Recipe> recipes = new List<Recipe>();

        public static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("____________________________________________\nWelcome to the Recipe Manager!\n______________________________________________");

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nMenu:\n_________________________________________\n");
                Console.WriteLine("1. Add New Recipe");
                Console.WriteLine("2. Show All Stored Recipes (Alphabetical Order)");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Clear Recipe Data");
                Console.WriteLine("5. Select a Recipe");
                Console.WriteLine("6. Exit\n________________________________________________");

                Console.Write("\nEnter your choice: ");
                string userChoice = Console.ReadLine();

                switch (userChoice)
                {
                    case "1":
                        AddNewRecipe();
                        break;
                    case "2":
                        ShowStoredRecipes();
                        break;
                    case "3":
                        ScaleRecipe();
                        break;
                    case "4":
                        ClearRecipeData();
                        break;
                    case "5":
                        SelectRecipe();
                        break;
                    case "6":
                        Console.WriteLine("Thank you for using Recipe Manager. Goodbye!");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }

        // Method to add a new recipe
        private static void AddNewRecipe()
        {
            Console.Write("\nEnter number of recipes to enter: ");
            int recipeCount;
            while (!int.TryParse(Console.ReadLine(), out recipeCount) || recipeCount <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer for the number of recipes.");
                Console.Write("Enter number of recipes to enter: ");
            }

            for (int j = 0; j < recipeCount; j++)
            {
                Recipe recipe = new Recipe();

                Console.Write("\nEnter name of the recipe: ");
                recipe.Name = Console.ReadLine();

                Console.Write("\nEnter number of ingredients: ");
                int ingredientCount;
                while (!int.TryParse(Console.ReadLine(), out ingredientCount) || ingredientCount <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive integer for the number of ingredients.");
                    Console.Write("Enter number of ingredients: ");
                }

                Console.WriteLine("\nEnter details for each ingredient:");
                recipe.Ingredients = new List<Ingredient>();

                for (int i = 0; i < ingredientCount; i++)
                {
                    Console.WriteLine($"\nIngredient {i + 1}:");
                    Console.Write("Name: ");
                    string ingredientName = Console.ReadLine().Trim();

                    Console.Write("Calories: ");
                    int calories;
                    while (!int.TryParse(Console.ReadLine(), out calories) || calories <= 0)
                    {
                        Console.WriteLine("Invalid input. Please enter a positive integer for calories.");
                        Console.Write("Calories: ");
                    }

                    Console.Write("Food Group: ");
                    string foodGroup = Console.ReadLine().Trim();

                    recipe.Ingredients.Add(new Ingredient
                    {
                        Name = ingredientName,
                        Calories = calories,
                        FoodGroup = foodGroup
                    });
                }

                recipes.Add(recipe);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nYour recipe has been added to the list!");
                Console.ResetColor();
            }
        }


        // Method to display all stored recipes
        private static void ShowStoredRecipes()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("\nNo recipes found.");
                return;
            }

            var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();

            Console.WriteLine("\nStored Recipes (Alphabetical Order):");
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("| No. | Recipe Name                             |");
            Console.WriteLine("-------------------------------------------------");

            for (int i = 0; i < sortedRecipes.Count; i++)
            {
                Console.WriteLine($"| {i + 1,-3} | {sortedRecipes[i].Name,-38} |");
            }

            Console.WriteLine("-------------------------------------------------");
        }

        // Method to scale a recipe
        private static void ScaleRecipe()
        {
            Console.Write("\nEnter the recipe name to scale: ");
            string recipeName = Console.ReadLine();

            var recipeToScale = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (recipeToScale != null)
            {
                Console.Write("Enter the scale factor (e.g., 2 for double the original recipe): ");
                if (int.TryParse(Console.ReadLine(), out int scaleFactor) && scaleFactor > 0)
                {
                    var scaledRecipe = new Recipe
                    {
                        Name = $"{recipeToScale.Name} (Scaled)",
                        Ingredients = new List<Ingredient>()
                    };

                    foreach (var ingredient in recipeToScale.Ingredients)
                    {
                        scaledRecipe.Ingredients.Add(new Ingredient
                        {
                            Name = ingredient.Name,
                            Calories = ingredient.Calories * scaleFactor,
                            FoodGroup = ingredient.FoodGroup
                        });
                    }

                    recipes.Add(scaledRecipe);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"\nScaled recipe '{scaledRecipe.Name}' has been added to the list!");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine("Invalid scale factor. Please enter a positive integer.");
                }
            }
            else
            {
                Console.WriteLine($"Recipe '{recipeName}' not found.");
            }
        }

        // Method to clear all recipe data
        private static void ClearRecipeData()
        {
            Console.WriteLine("\nClearing all recipe data...");
            recipes.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("All recipe data cleared successfully!");
            Console.ResetColor();
        }

        // Method to select and display details of a recipe
        private static void SelectRecipe()
        {
            ShowStoredRecipes();

            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available to select.");
                return;
            }

            Console.Write("\nEnter the recipe number to view details: ");
            if (int.TryParse(Console.ReadLine(), out int recipeNumber) && recipeNumber >= 1 && recipeNumber <= recipes.Count)
            {
                Recipe selectedRecipe = recipes[recipeNumber - 1];
                Console.WriteLine($"\nRecipe: {selectedRecipe.Name}\n");

                Console.WriteLine("Ingredients:");
                Console.WriteLine("----------------------------------");
                Console.WriteLine("| No. | Name             | Calories |");
                Console.WriteLine("----------------------------------");

                for (int i = 0; i < selectedRecipe.Ingredients.Count; i++)
                {
                    Ingredient ingredient = selectedRecipe.Ingredients[i];
                    Console.WriteLine($"| {i + 1,-3} | {ingredient.Name,-16} | {ingredient.Calories,-8} |");
                }

                Console.WriteLine("----------------------------------");

                int totalCalories = selectedRecipe.CalculateTotalCalories();
                Console.WriteLine($"\nTotal calories: {totalCalories}");

                if (totalCalories > 300)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Warning: This recipe exceeds 300 calories!");
                    Console.ResetColor();
                }
            }
            else
            {
                Console.WriteLine("Invalid recipe number. Please select a valid recipe.");
            }
        }
    }
}
